@echo off
setlocal
echo This helper is optional. Build-WIM.cmd already performs these steps.
echo.
echo Use Build-WIM.cmd for the normal workflow.
pause
