Win10-WIM-Tool v1.0
====================

目标系统：
Windows 10 22H2 Professional x64

本版本只实现：
1. Sysprep /generalize
2. 自动 OOBE
3. 创建本地管理员 PC
4. PC 密码为空
5. 自动第一次登录
6. 首次登录运行 FirstBoot.ps1
7. 读取 BIOS/SMBIOS 序列号
8. 有效序列号 -> 计算机名改为序列号
9. 无效/组装机序列号 -> 保留 Windows 默认计算机名
10. Sysprep 后使用 WinPE + DISM 捕获标准 install.wim

不包含：
- 自动安装软件
- 自动更新
- 驱动注入
- 激活
- 加域
- 网络配置
- 集中式部署日志

============================================================
一、母盘操作
============================================================

1. 在 Windows 10 22H2 Professional x64 母盘中，把整个
   Win10-WIM-Tool 文件夹复制到例如：

   C:\Win10-WIM-Tool

2. 确认母盘已经处于你希望封装的状态。

3. 以管理员身份运行：

   C:\Win10-WIM-Tool\Build-WIM.cmd

4. 确认继续后，工具会：
   - 写入 C:\Windows\Panther\Unattend.xml
   - 写入 C:\Windows\Setup\Scripts\FirstBoot.ps1
   - 写入 FirstBoot.cmd
   - 执行 Sysprep /generalize /oobe /shutdown

5. Sysprep 成功后电脑会关机。

============================================================
二、捕获 WIM
============================================================

1. 使用 WinPE 启动母盘电脑。

2. 把本工具放到 U 盘或其他可访问的位置。

3. 运行：

   Capture-WIM.cmd

4. 脚本自动检测 Windows 分区并显示，例如 D:。
   - 检测正确：直接按回车确认。
   - 检测错误：输入正确的盘符，脚本会重新校验。
   - 如果发现多个 Windows 安装，脚本会列出让你选择。

5. 输入保存 WIM 的盘符：
   - 直接按回车 = 保存到脚本所在的盘（通常是 U 盘）。
   - 或输入其他盘符，例如 E:。
   注意：WIM 不能保存到正在捕获的 Windows 分区本身。

6. 最终生成：

   C:\WIM\install.wim（盘符以第 5 步输入为准）

============================================================
三、部署测试
============================================================

把 install.wim 部署到另一台测试电脑。

预期：

Windows 安装完成后自动完成 OOBE，
自动创建 PC 本地管理员，
自动进入桌面。

第一次进入桌面时执行：

C:\Windows\Setup\Scripts\FirstBoot.ps1

如果读取到有效 SN：

计算机名 = SN（清理非法字符并限制为 15 字符）

如果 SN 是空值或 OEM 占位符：

不修改计算机名。

如果进行了改名，电脑会自动重启一次。

日志（仅用于本次功能排错）：

C:\Windows\Setup\Scripts\FirstBoot.log

============================================================
四、重要说明
============================================================

本工具第一版针对 Windows 10 22H2 Professional x64。
不要直接用于 Windows 11。

第一次测试强烈建议使用 VMware/Hyper-V 虚拟机或备用实体机，
不要直接拿生产电脑验证。

如果 Sysprep 失败，请检查：

C:\Windows\System32\Sysprep\Panther\setuperr.log
C:\Windows\System32\Sysprep\Panther\setupact.log

============================================================
