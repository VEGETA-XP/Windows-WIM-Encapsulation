@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Win10 WIM Tool v1.0.1 - Capture Image

echo ============================================================
echo   Win10-WIM-Tool v1.0.1 - WIM Capture
echo ============================================================
echo.
echo This script is designed to run from WinPE.
echo It will automatically detect the Windows installation
echo partition instead of assuming it is C:.
echo.

:: Locate DISM.exe without relying on PATH.
:: In WinPE it normally lives in X:\Windows\System32.
:: Some PE builds have a broken/minimal PATH or lack where.exe,
:: which makes "where dism.exe" fail even though DISM.exe is present.
set "DISM="
if exist "%SystemRoot%\System32\Dism.exe" set "DISM=%SystemRoot%\System32\Dism.exe"
if not defined DISM if exist "%WINDIR%\System32\Dism.exe" set "DISM=%WINDIR%\System32\Dism.exe"
if not defined DISM if exist "X:\Windows\System32\Dism.exe" set "DISM=X:\Windows\System32\Dism.exe"
if not defined DISM if exist "C:\Windows\System32\Dism.exe" set "DISM=C:\Windows\System32\Dism.exe"
if not defined DISM (
    where dism.exe >nul 2>&1
    if not errorlevel 1 set "DISM=dism.exe"
)

if not defined DISM (
    echo [ERROR] DISM.exe was not found in any known location.
    echo.
    echo Checked:
    echo   %SystemRoot%\System32\Dism.exe
    echo   X:\Windows\System32\Dism.exe
    echo   C:\Windows\System32\Dism.exe
    echo.
    echo This script must be run from a WinPE that includes DISM.
    echo In the PE command prompt, verify with:
    echo   if exist X:\Windows\System32\Dism.exe echo DISM OK
    echo.
    echo If the PE has no DISM.exe, use a standard WinPE built
    echo from the Windows ADK, or add the DISM component to your PE.
    pause
    exit /b 1
)

echo [OK] DISM found: %DISM%
echo.

echo [1/3] Detecting Windows installation partition...
echo.

:: Stronger detection: a drive counts only if it has ALL of:
::   Windows\System32\Config\SYSTEM   (registry hive)
::   Windows\System32\ntoskrnl.exe    (kernel)
::   Windows\System32\winload.efi or winload.exe  (boot loader)
set "WIN_LIST="
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%D:\Windows\System32\Config\SYSTEM" (
        if exist "%%D:\Windows\System32\ntoskrnl.exe" (
            if exist "%%D:\Windows\System32\winload.efi" (
                set "WIN_LIST=!WIN_LIST! %%D:"
            ) else if exist "%%D:\Windows\System32\winload.exe" (
                set "WIN_LIST=!WIN_LIST! %%D:"
            )
        )
    )
)

set "WIN_COUNT=0"
for %%W in (%WIN_LIST%) do set /a WIN_COUNT+=1

if %WIN_COUNT% EQU 0 (
    echo [ERROR] Could not automatically locate the Windows installation.
    echo.
    echo Checked every drive for:
    echo   Windows\System32\Config\SYSTEM
    echo   Windows\System32\ntoskrnl.exe
    echo   Windows\System32\winload.efi or winload.exe
    echo.
    echo You can list drives in the PE command prompt with:
    echo   diskpart
    echo   list volume
    echo.
    pause
    exit /b 1
)

if %WIN_COUNT% GTR 1 (
    echo [WARNING] More than one Windows installation was found:
    echo   %WIN_LIST%
    echo.
    echo Please choose the correct one below.
    set "WIN="
) else (
    for %%W in (%WIN_LIST%) do set "WIN=%%W"
    echo [OK] Windows installation detected: !WIN!
    echo.
)

:confirm_win
set /a WIN_TRY+=1
if %WIN_TRY% GTR 5 (
    echo [ERROR] Too many invalid Windows drive attempts. Aborting.
    pause
    exit /b 1
)
set "WIN_IN="
if defined WIN (
    set /p "WIN_IN=Press Enter to confirm %WIN%, or type the correct drive letter [e.g. C]: "
) else (
    set /p "WIN_IN=Enter the correct Windows drive from the list above [e.g. D]: "
)
if not defined WIN_IN (
    if defined WIN goto :win_confirmed
    echo [ERROR] A Windows drive must be selected when multiple installations are found.
    echo.
    goto :confirm_win
)

:: Normalize the typed drive letter.
if defined WIN_IN set "WIN_IN=!WIN_IN: =!"
if defined WIN_IN set "WIN_IN=!WIN_IN:"=!"
if not defined WIN_IN (
    if defined WIN goto :win_confirmed
    echo [ERROR] A Windows drive must be selected when multiple installations are found.
    echo.
    goto :confirm_win
)
set "WIN_IN=%WIN_IN:~0,1%:"

:: Re-validate the typed drive with the same markers, so a wrong
:: letter cannot silently proceed.
if not exist "%WIN_IN%\Windows\System32\Config\SYSTEM" goto :win_bad
if not exist "%WIN_IN%\Windows\System32\ntoskrnl.exe" goto :win_bad
if not exist "%WIN_IN%\Windows\System32\winload.efi" (
    if not exist "%WIN_IN%\Windows\System32\winload.exe" goto :win_bad
)
set "WIN=%WIN_IN%"
echo.
echo [OK] Windows installation set to: %WIN%
echo.
goto :win_confirmed

:win_bad
echo [ERROR] "%WIN_IN%" is not a Windows installation drive.
echo Checked:
echo   %WIN_IN%\Windows\System32\Config\SYSTEM
echo   %WIN_IN%\Windows\System32\ntoskrnl.exe
echo   %WIN_IN%\Windows\System32\winload.efi / winload.exe
echo.
goto :confirm_win

:win_confirmed
echo.
echo The Windows source drive is %WIN%.
echo The WIM cannot be saved on %WIN% itself because that partition
echo is being captured. Usually the WIM goes to the USB drive.
echo The drive this script is running from: %~d0
echo.

:ask_dest
set /a DEST_TRY+=1
if %DEST_TRY% GTR 5 (
    echo [ERROR] Too many invalid output drive attempts. Aborting.
    pause
    exit /b 1
)
set "DEST="
set /p "DEST=Output drive [Enter=%~d0 / type another letter, e.g. E]: "
if not defined DEST set "DEST=%~d0"
if defined DEST set "DEST=!DEST: =!"
if defined DEST set "DEST=!DEST:"=!"
if not defined DEST set "DEST=%~d0"
set "DEST=%DEST:~0,1%:"

:: Validate the output drive letter.
set "DEST_OK="
for %%L in (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if /i "!DEST!"=="%%L:" set "DEST_OK=1"
)
if not defined DEST_OK (
    echo [ERROR] "%DEST%" is not a valid drive letter.
    echo Please enter a single drive letter, for example C or C:.
    echo.
    goto :ask_dest
)

if /i "%DEST%"=="%WIN%" (
    echo [ERROR] Output drive cannot be the Windows installation drive.
    echo Windows source: %WIN%
    echo The partition being captured cannot also hold the WIM file.
    echo.
    goto :ask_dest
)

if not exist "%DEST%\" (
    echo [ERROR] Destination drive %DEST% does not exist.
    echo.
    echo In the PE command prompt you can list drives with:
    echo   diskpart
    echo   list volume
    echo.
    goto :ask_dest
)

echo [OK] Output drive: %DEST%
echo.

if not exist "%DEST%\WIM" mkdir "%DEST%\WIM"

set "WIM=%DEST%\WIM\install.wim"

if exist "%WIM%" (
    echo.
    echo [WARNING] Existing WIM found:
    echo %WIM%
    choice /C YN /N /M "Overwrite it? [Y/N]: "
    if errorlevel 2 exit /b 0
    del /f /q "%WIM%" >nul 2>&1
)

echo.
echo [2/3] Capturing Windows image...
echo.
echo Source: %WIN%\
echo WIM:    %WIM%
echo.
echo This may take a while. Do not power off the computer.
echo.

"%DISM%" /Capture-Image /ImageFile:"%WIM%" /CaptureDir:%WIN%\ /Name:"Windows 10 22H2 Professional x64" /Description:"Windows 10 22H2 Professional x64 - Win10-WIM-Tool v1.0.1" /Compress:Max /CheckIntegrity

if errorlevel 1 (
    echo.
    echo ============================================================
    echo [ERROR] DISM image capture failed.
    echo ============================================================
    echo.
    echo The Windows source was detected as:
    echo %WIN%\
    echo.
    echo Please copy the complete DISM error shown above.
    pause
    exit /b 1
)

echo.
echo [3/3] Verifying WIM...
echo.

"%DISM%" /Get-WimInfo /WimFile:"%WIM%"

if errorlevel 1 (
    echo.
    echo [ERROR] WIM was created but verification failed.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo WIM created successfully.
echo ============================================================
echo.
echo %WIM%
echo.
pause
exit /b 0
