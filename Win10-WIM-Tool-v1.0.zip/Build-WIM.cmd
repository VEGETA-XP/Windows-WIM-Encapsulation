@echo off
setlocal EnableExtensions
title Win10 WIM Tool - Prepare Image

echo ============================================================
echo   Win10-WIM-Tool v1.0
echo   Windows 10 22H2 Professional x64
echo ============================================================
echo.
echo This script prepares the current Windows installation for
echo Sysprep and writes the unattended/first-boot configuration.
echo.
pause

:: Must run elevated
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo [ERROR] Please run this script as Administrator.
    pause
    exit /b 1
)

:: Check Windows version / architecture
for /f "tokens=2 delims==" %%A in ('wmic os get Caption /value ^| find "="') do set "OSCAPTION=%%A"
for /f "tokens=2 delims==" %%A in ('wmic os get BuildNumber /value ^| find "="') do set "BUILD=%%A"
if not defined OSCAPTION set "OSCAPTION=Unknown"

echo [INFO] Windows: %OSCAPTION%
echo [INFO] Build:   %BUILD%
echo.

if /i not "%PROCESSOR_ARCHITECTURE%"=="AMD64" (
    echo [ERROR] This tool is intended for Windows x64.
    pause
    exit /b 1
)

:: Prepare directories
if not exist "%WINDIR%\Setup\Scripts" mkdir "%WINDIR%\Setup\Scripts"
if not exist "%WINDIR%\Panther" mkdir "%WINDIR%\Panther"

echo [1/4] Copying FirstBoot.ps1...
copy /y "%~dp0scripts\FirstBoot.ps1" "%WINDIR%\Setup\Scripts\FirstBoot.ps1" >nul
if errorlevel 1 goto :copy_error

echo [2/4] Copying Unattend.xml...
copy /y "%~dp0config\Unattend.xml" "%WINDIR%\Panther\Unattend.xml" >nul
if errorlevel 1 goto :copy_error

echo [3/4] Creating first-boot launcher...
(
echo @echo off
echo powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%%WINDIR%%\Setup\Scripts\FirstBoot.ps1"
) > "%WINDIR%\Setup\Scripts\FirstBoot.cmd"

echo.
echo [4/4] Starting Sysprep...
echo.
echo WARNING:
echo Sysprep will generalize this Windows installation and shut down
echo the computer when finished.
echo.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 exit /b 0

"%WINDIR%\System32\Sysprep\Sysprep.exe" /generalize /oobe /shutdown /unattend:"%WINDIR%\Panther\Unattend.xml"

if errorlevel 1 (
    echo.
    echo [ERROR] Sysprep returned an error.
    echo Check:
    echo   %WINDIR%\System32\Sysprep\Panther\setuperr.log
    echo   %WINDIR%\System32\Sysprep\Panther\setupact.log
    pause
    exit /b 1
)

echo.
echo Sysprep completed. The computer should now be shut down.
echo Boot this computer into WinPE and run Capture-WIM.cmd.
pause
exit /b 0

:copy_error
echo [ERROR] Failed to copy required files.
pause
exit /b 1
