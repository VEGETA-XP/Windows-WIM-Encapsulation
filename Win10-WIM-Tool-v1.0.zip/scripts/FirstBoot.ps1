# Win10-WIM-Tool v1.0
# First boot: rename computer to a valid BIOS/SMBIOS serial number.
# If no usable serial number exists, leave the Windows-generated name unchanged.

$ErrorActionPreference = "Stop"

$LogFile = Join-Path $env:WINDIR "Setup\Scripts\FirstBoot.log"

function Write-Log {
    param([string]$Message)
    $line = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

function Get-SerialNumber {
    try {
        $bios = Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop
        return ([string]$bios.SerialNumber).Trim()
    } catch {
        Write-Log "ERROR: Unable to read BIOS serial number: $($_.Exception.Message)"
        return ""
    }
}

function Test-UsableSerial {
    param([string]$Serial)

    if ([string]::IsNullOrWhiteSpace($Serial)) {
        return $false
    }

    $s = $Serial.Trim()

    $invalid = @(
        "TO BE FILLED BY O.E.M.",
        "TO BE FILLED BY OEM",
        "DEFAULT STRING",
        "SYSTEM SERIAL NUMBER",
        "UNKNOWN",
        "NONE",
        "NULL",
        "NOT SPECIFIED",
        "NOT AVAILABLE"
    )

    foreach ($item in $invalid) {
        if ($s -ieq $item) {
            return $false
        }
    }

    # Windows computer names may contain letters, digits and hyphens.
    # Replace other characters rather than failing the deployment.
    $safe = $s -replace '[^A-Za-z0-9-]', '-'
    $safe = $safe.Trim('-')

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return $false
    }

    if ($safe.Length -gt 15) {
        $safe = $safe.Substring(0, 15)
    }

    if ($safe -match '^[0-9]+$') {
        return $false
    }

    return $safe
}

function Clear-PasswordChangeFlag {
    # Defense in depth: make sure the local PC account is not flagged
    # "user must change password at next logon". An empty password in
    # Unattend.xml normally prevents this flag; this clears it just in case.
    try {
        $acc = [ADSI]"WinNT://$env:COMPUTERNAME/PC,user"
        $wasExpired = [int]$acc.PasswordExpired.Value
        if ($wasExpired -eq 1) {
            $acc.PasswordExpired = 0
            $acc.SetInfo()
            Write-Log "PC account password-change flag was set; cleared it."
        } else {
            Write-Log "PC account password-change flag is not set."
        }
    } catch {
        Write-Log "WARNING: Could not inspect/clear PC password-change flag: $($_.Exception.Message)"
    }
}

try {
    Write-Log "FirstBoot started."

    Clear-PasswordChangeFlag

    $serial = Get-SerialNumber
    Write-Log "BIOS serial: [$serial]"

    $newName = Test-UsableSerial -Serial $serial

    if (-not $newName) {
        Write-Log "No usable serial number. Computer name will not be changed."
        Write-Log "FirstBoot completed."
        exit 0
    }

    $currentName = $env:COMPUTERNAME
    Write-Log "Current computer name: [$currentName]"
    Write-Log "Target computer name:  [$newName]"

    if ($currentName -ieq $newName) {
        Write-Log "Computer name already matches target. No rename required."
        Write-Log "FirstBoot completed."
        exit 0
    }

    Rename-Computer -NewName $newName -Force -ErrorAction Stop
    Write-Log "Computer rename command completed successfully."
    Write-Log "A restart is required."

    shutdown.exe /r /t 15 /c "Windows initial deployment completed. Restarting to apply computer name." /f

} catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    exit 1
}
